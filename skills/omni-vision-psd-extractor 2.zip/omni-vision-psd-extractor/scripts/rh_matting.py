#!/usr/bin/env python3
"""
RH抠图王 (RunningHub Matting) 接口脚本
替换原来的本地去绿幕处理，使用云端高精度抠图服务
"""

import argparse
import asyncio
import base64
import json
import sys
import time
from pathlib import Path

try:
    import httpx
    USE_HTTPX = True
except ImportError:
    import urllib.request
    import urllib.parse
    USE_HTTPX = False
    print("[Warning] httpx 未安装，使用 urllib（建议: pip install httpx）", file=sys.stderr)


# RH抠图王配置
RH_API_KEY = "442de49dcb5247a285b678a4c70e7499"
RH_BASE_URL = "https://n8n.lconai.com/webhook/c662eebb-0a0b-4c4d-8df4-7b5b01d2b27a"


def parse_args():
    parser = argparse.ArgumentParser(description="RH抠图王 - 云端高精度抠图服务")
    parser.add_argument("--input", required=True, help="输入图片路径（绿幕背景）")
    parser.add_argument("--output", required=True, help="输出图片路径（透明背景）")
    parser.add_argument("--mode", default="auto", help="抠图模式（保留参数兼容性，RH抠图王自动处理）")
    parser.add_argument("--tolerance", type=int, default=30, help="容差值（保留参数兼容性）")
    parser.add_argument("--max-wait", type=int, default=120, help="最大等待时间（秒）")
    parser.add_argument("--poll-interval", type=int, default=2, help="轮询间隔（秒）")
    return parser.parse_args()


async def call_rh_matting_async(input_path: Path, output_path: Path, max_wait: int = 120, poll_interval: int = 2):
    """
    使用 httpx 异步调用 RH抠图王 API
    """
    # 读取图片并转为 Base64
    with open(input_path, 'rb') as f:
        image_data = f.read()
    image_b64 = base64.b64encode(image_data).decode('utf-8')

    print(f"[RH抠图王] 正在上传图片: {input_path.name} ({len(image_data) / 1024:.2f} KB)", file=sys.stderr)

    async with httpx.AsyncClient(timeout=30.0) as client:
        # Step 1: 提交抠图任务
        payload = {
            "action": "matting",
            "image": image_b64,
            "format": "png"
        }
        headers = {
            "Authorization": f"Bearer {RH_API_KEY}",
            "Content-Type": "application/json"
        }

        try:
            submit_resp = await client.post(RH_BASE_URL, json=payload, headers=headers)
            if submit_resp.status_code != 200:
                raise Exception(f"提交失败 HTTP {submit_resp.status_code}: {submit_resp.text[:500]}")

            submit_data = submit_resp.json()
            request_id = submit_data.get("requestId")

            if not request_id:
                raise Exception(f"未获取到 requestId: {submit_data}")

            print(f"[RH抠图王] ✅ 任务已提交，requestId: {request_id}", file=sys.stderr)

        except Exception as e:
            raise Exception(f"任务提交失败: {e}")

        # Step 2: 轮询任务状态
        start_time = time.time()
        query_payload = {
            "action": "query",
            "requestId": request_id
        }

        while time.time() - start_time < max_wait:
            await asyncio.sleep(poll_interval)

            try:
                query_resp = await client.post(RH_BASE_URL, json=query_payload, headers=headers)
                if query_resp.status_code != 200:
                    print(f"[RH抠图王] 查询失败 HTTP {query_resp.status_code}", file=sys.stderr)
                    continue

                query_data = query_resp.json()
                status = query_data.get("status")

                elapsed = int(time.time() - start_time)
                print(f"[RH抠图王] 状态: {status} (已等待 {elapsed}s)", file=sys.stderr)

                if status == "SUCCESS":
                    results = query_data.get("results", [])
                    if not results:
                        raise Exception("任务成功但无结果图片")

                    result_url = results[0].get("url")
                    print(f"[RH抠图王] ✅ 抠图完成，下载结果: {result_url}", file=sys.stderr)

                    # Step 3: 下载结果图片
                    img_resp = await client.get(result_url, timeout=30)
                    if img_resp.status_code != 200:
                        raise Exception(f"图片下载失败 HTTP {img_resp.status_code}")

                    # 保存到输出路径
                    output_path.parent.mkdir(parents=True, exist_ok=True)
                    output_path.write_bytes(img_resp.content)

                    print(f"[RH抠图王] ✅ 透明PNG已保存: {output_path}", file=sys.stderr)
                    return True

                elif status == "FAILED":
                    error_msg = query_data.get("errorMessage", "未知错误")
                    raise Exception(f"RH抠图王任务失败: {error_msg}")

            except Exception as e:
                print(f"[RH抠图王] 查询出错: {e}", file=sys.stderr)
                continue

        raise Exception(f"RH抠图王等待超时 ({max_wait}s)")


def call_rh_matting_urllib(input_path: Path, output_path: Path, max_wait: int = 120, poll_interval: int = 2):
    """
    使用 urllib 同步调用 RH抠图王 API（备用）
    """
    # 读取图片并转为 Base64
    with open(input_path, 'rb') as f:
        image_data = f.read()
    image_b64 = base64.b64encode(image_data).decode('utf-8')

    print(f"[RH抠图王] 正在上传图片: {input_path.name} ({len(image_data) / 1024:.2f} KB)", file=sys.stderr)

    # Step 1: 提交抠图任务
    payload = {
        "action": "matting",
        "image": image_b64,
        "format": "png"
    }
    headers = {
        "Authorization": f"Bearer {RH_API_KEY}",
        "Content-Type": "application/json"
    }

    try:
        request = urllib.request.Request(
            RH_BASE_URL,
            data=json.dumps(payload).encode('utf-8'),
            headers=headers,
            method="POST"
        )
        with urllib.request.urlopen(request, timeout=30) as response:
            submit_data = json.loads(response.read().decode('utf-8'))

        request_id = submit_data.get("requestId")
        if not request_id:
            raise Exception(f"未获取到 requestId: {submit_data}")

        print(f"[RH抠图王] ✅ 任务已提交，requestId: {request_id}", file=sys.stderr)

    except Exception as e:
        raise Exception(f"任务提交失败: {e}")

    # Step 2: 轮询任务状态
    start_time = time.time()
    query_payload = {
        "action": "query",
        "requestId": request_id
    }

    while time.time() - start_time < max_wait:
        time.sleep(poll_interval)

        try:
            request = urllib.request.Request(
                RH_BASE_URL,
                data=json.dumps(query_payload).encode('utf-8'),
                headers=headers,
                method="POST"
            )
            with urllib.request.urlopen(request, timeout=30) as response:
                query_data = json.loads(response.read().decode('utf-8'))

            status = query_data.get("status")
            elapsed = int(time.time() - start_time)
            print(f"[RH抠图王] 状态: {status} (已等待 {elapsed}s)", file=sys.stderr)

            if status == "SUCCESS":
                results = query_data.get("results", [])
                if not results:
                    raise Exception("任务成功但无结果图片")

                result_url = results[0].get("url")
                print(f"[RH抠图王] ✅ 抠图完成，下载结果: {result_url}", file=sys.stderr)

                # Step 3: 下载结果图片
                with urllib.request.urlopen(result_url, timeout=30) as img_resp:
                    img_data = img_resp.read()

                # 保存到输出路径
                output_path.parent.mkdir(parents=True, exist_ok=True)
                output_path.write_bytes(img_data)

                print(f"[RH抠图王] ✅ 透明PNG已保存: {output_path}", file=sys.stderr)
                return True

            elif status == "FAILED":
                error_msg = query_data.get("errorMessage", "未知错误")
                raise Exception(f"RH抠图王任务失败: {error_msg}")

        except Exception as e:
            print(f"[RH抠图王] 查询出错: {e}", file=sys.stderr)
            continue

    raise Exception(f"RH抠图王等待超时 ({max_wait}s)")


def main():
    args = parse_args()
    input_path = Path(args.input)
    output_path = Path(args.output)

    if not input_path.exists():
        print(f"❌ 输入文件不存在: {input_path}", file=sys.stderr)
        return 1

    try:
        if USE_HTTPX:
            # 使用 httpx 异步调用（推荐）
            asyncio.run(call_rh_matting_async(input_path, output_path, args.max_wait, args.poll_interval))
        else:
            # 使用 urllib 同步调用（备用）
            call_rh_matting_urllib(input_path, output_path, args.max_wait, args.poll_interval)

        print(f"✅ RH抠图王处理完成", file=sys.stderr)
        return 0

    except Exception as e:
        print(f"❌ RH抠图王处理失败: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
