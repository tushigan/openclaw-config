# Long-Term Memory


## Promoted From Short-Term Memory (2026-05-13)

<!-- openclaw-memory-promotion:memory:memory/2026-05-05.md:226:226 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-05.md:208-208]
<!-- openclaw-memory-promotion:memory:memory/2026-05-06.md:251:251 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-06.md:238-238]
<!-- openclaw-memory-promotion:memory:memory/2026-05-07.md:326:326 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-07.md:313-313]
<!-- openclaw-memory-promotion:memory:memory/2026-05-08.md:406:408 -->
- - Candidate: Possible Lasting Truths: - Candidate: User: System: [2026-04-09 14:48:04 GMT+8] Feishu[strategy] DM | 涂是淦 (ou_442533093a478558484ef6461b4d4a56) [msg:om_x100b5240f4f71484c496e9e5c32958e] Conversation info (untrusted metadata): ```json { "message_id": "om_x100b5240f4f71484c496e9e5c - confidence: 0.00 - evidence: memory/2026-05-08.md:406-408 [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-08.md:8-10]
<!-- openclaw-memory-promotion:memory:memory/2026-05-05.md:223:223 -->
- - Candidate: Reflections: No strong patterns surfaced. [score=0.825 recalls=0 avg=0.620 source=memory/2026-05-05.md:78-78]
<!-- openclaw-memory-promotion:memory:memory/2026-05-06.md:248:248 -->
- - Candidate: Reflections: No strong patterns surfaced. [score=0.825 recalls=0 avg=0.620 source=memory/2026-05-06.md:218-218]
<!-- openclaw-memory-promotion:memory:memory/2026-05-07.md:323:323 -->
- - Candidate: Reflections: No strong patterns surfaced. [score=0.818 recalls=0 avg=0.620 source=memory/2026-05-07.md:308-308]
<!-- openclaw-memory-promotion:memory:memory/2026-05-08.md:403:403 -->
- - Candidate: Reflections: No strong patterns surfaced. [score=0.818 recalls=0 avg=0.620 source=memory/2026-05-08.md:213-213]

## Promoted From Short-Term Memory (2026-05-14)

<!-- openclaw-memory-promotion:memory:memory/2026-05-09.md:398:398 -->
- - Candidate: Reflections: No strong patterns surfaced. [score=0.818 recalls=0 avg=0.620 source=memory/2026-05-09.md:293-293]

## Promoted From Short-Term Memory (2026-05-16)

<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:308:308 -->
- - Candidate: Reflections: No strong patterns surfaced. [score=0.841 recalls=0 avg=0.620 source=memory/2026-05-10.md:273-273]
<!-- openclaw-memory-promotion:memory:memory/2026-05-11.md:288:288 -->
- - Candidate: Reflections: No strong patterns surfaced. [score=0.834 recalls=0 avg=0.620 source=memory/2026-05-11.md:93-93]

## Promoted From Short-Term Memory (2026-05-21)

<!-- openclaw-memory-promotion:memory:memory/2026-05-16.md:5:7 -->
- **时间**：2026-05-16 上午 **对象**：鸿诚 刘总（电话） **起因**：跟进昨天发出的报价 [score=0.827 recalls=0 avg=0.620 source=memory/2026-05-16.md:5-7]
<!-- openclaw-memory-promotion:memory:memory/2026-05-16.md:31:31 -->
- _记录人：strategy / 来源：涂是淦口述_ [score=0.817 recalls=0 avg=0.620 source=memory/2026-05-16.md:31-31]
