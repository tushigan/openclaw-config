# Long-Term Memory


## Promoted From Short-Term Memory (2026-05-13)

<!-- openclaw-memory-promotion:memory:memory/2026-05-08.md:138:141 -->
- - Candidate: Reflections: Theme: `kept` kept surfacing across 28 memories.; confidence: 1.00; evidence: memory/2026-05-08.md:63-66, memory/2026-05-08.md:67-70, memory/2026-05-08.md:78-81; note: reflection - confidence: 0.00 - evidence: memory/2026-05-08.md:138-141 - recalls: 0 [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-08.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-08.md:152:152 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-08.md:8-8]

## Promoted From Short-Term Memory (2026-05-14)

<!-- openclaw-memory-promotion:memory:memory/2026-05-09.md:173:176 -->
- - Candidate: Reflections: Theme: `kept` kept surfacing across 37 memories.; confidence: 1.00; evidence: memory/2026-05-08.md:63-66, memory/2026-05-08.md:67-70, memory/2026-05-08.md:78-81; note: reflection - confidence: 0.00 - evidence: memory/2026-05-09.md:173-176 - recalls: 0 [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-09.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-09.md:187:187 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-09.md:23-23]

## Promoted From Short-Term Memory (2026-05-15)

<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:183:186 -->
- - Candidate: Reflections: Theme: `67-70` kept surfacing across 48 memories.; confidence: 0.78; evidence: memory/2026-05-08.md:117-120, memory/2026-05-08.md:121-124, memory/2026-05-08.md:125-128; note: reflection - confidence: 0.00 - evidence: memory/2026-05-10.md:183-186 - recalls: 0 [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-10.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:187:190 -->
- - Candidate: Reflections: Theme: `78-81` kept surfacing across 48 memories.; confidence: 0.78; evidence: memory/2026-05-08.md:117-120, memory/2026-05-08.md:121-124, memory/2026-05-08.md:125-128; note: reflection - confidence: 0.00 - evidence: memory/2026-05-10.md:187-190 - recalls: 0 [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-10.md:8-11]
<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:163:166 -->
- - Candidate: Reflections: Theme: `reflections` kept surfacing across 81 memories.; confidence: 1.00; evidence: memory/2026-05-08.md:63-66, memory/2026-05-08.md:67-70, memory/2026-05-08.md:78-81; note: reflection - confidence: 0.00 - evidence: memory/2026-05-10.md:163-166 - recalls: 0 [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-10.md:13-16]
<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:171:174 -->
- - Candidate: Reflections: Theme: `memory/2026-05-08.md` kept surfacing across 69 memories.; confidence: 1.00; evidence: memory/2026-05-08.md:117-120, memory/2026-05-08.md:121-124, memory/2026-05-08.md:125-128; note: reflection - confidence: 0.00 - evidence: memory/2026-05-10.md:171-174 - recalls: 0 [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-10.md:18-21]
<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:175:178 -->
- - Candidate: Reflections: Theme: `kept` kept surfacing across 60 memories.; confidence: 0.98; evidence: memory/2026-05-08.md:63-66, memory/2026-05-08.md:67-70, memory/2026-05-08.md:78-81; note: reflection - confidence: 0.00 - evidence: memory/2026-05-10.md:175-178 - recalls: 0 [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-10.md:23-26]
<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:179:182 -->
- - Candidate: Reflections: Theme: `63-66` kept surfacing across 48 memories.; confidence: 0.78; evidence: memory/2026-05-08.md:117-120, memory/2026-05-08.md:121-124, memory/2026-05-08.md:125-128; note: reflection - confidence: 0.00 - evidence: memory/2026-05-10.md:179-182 - recalls: 0 [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-10.md:28-31]
<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:193:193 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-10.md:93-93]

## Promoted From Short-Term Memory (2026-05-16)

<!-- openclaw-memory-promotion:memory:memory/2026-05-11.md:188:188 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.849 recalls=0 avg=0.620 source=memory/2026-05-11.md:108-108]
