# Long-Term Memory


## Promoted From Short-Term Memory (2026-05-13)

<!-- openclaw-memory-promotion:memory:memory/2026-05-05.md:193:196 -->
- - Candidate: Reflections: Theme: `157-160` kept surfacing across 244 memories.; confidence: 1.00; evidence: memory/2026-04-27.md:303-306, memory/2026-04-27.md:307-310, memory/2026-04-27.md:311-314; note: reflection - confidence: 0.00 - evidence: memory/2026-05-05.md:193-196 - recalls: 0 [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-05.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-05.md:189:192 -->
- - Candidate: Reflections: Theme: `153-156` kept surfacing across 244 memories.; confidence: 1.00; evidence: memory/2026-04-27.md:303-306, memory/2026-04-27.md:307-310, memory/2026-04-27.md:311-314; note: reflection - confidence: 0.00 - evidence: memory/2026-05-05.md:189-192 - recalls: 0 [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-05.md:18-21]
<!-- openclaw-memory-promotion:memory:memory/2026-05-06.md:318:321 -->
- - Candidate: Reflections: Theme: `reflections` kept surfacing across 398 memories.; confidence: 1.00; evidence: memory/2026-04-22.md:293-296, memory/2026-04-22.md:297-300, memory/2026-04-22.md:301-304; note: reflection - confidence: 0.00 - evidence: memory/2026-05-06.md:318-321 - recalls: 0 [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-06.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-06.md:330:333 -->
- - Candidate: Reflections: Theme: `kept` kept surfacing across 245 memories.; confidence: 0.94; evidence: memory/2026-04-22.md:293-296, memory/2026-04-22.md:297-300, memory/2026-04-22.md:301-304; note: reflection - confidence: 0.00 - evidence: memory/2026-05-06.md:330-333 - recalls: 0 [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-06.md:8-11]
<!-- openclaw-memory-promotion:memory:memory/2026-05-06.md:334:337 -->
- - Candidate: Reflections: Theme: `memory/2026-04-19.md` kept surfacing across 230 memories.; confidence: 0.88; evidence: memory/2026-04-22.md:293-296, memory/2026-04-22.md:297-300, memory/2026-04-22.md:301-304; note: reflection - confidence: 0.00 - evidence: memory/2026-05-06.md:334-337 - recalls: 0 [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-06.md:13-16]
<!-- openclaw-memory-promotion:memory:memory/2026-05-06.md:338:341 -->
- - Candidate: Reflections: Theme: `153-156` kept surfacing across 221 memories.; confidence: 0.85; evidence: memory/2026-04-27.md:303-306, memory/2026-04-27.md:307-310, memory/2026-04-27.md:311-314; note: reflection - confidence: 0.00 - evidence: memory/2026-05-06.md:338-341 - recalls: 0 [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-06.md:18-21]
<!-- openclaw-memory-promotion:memory:memory/2026-05-07.md:342:342 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-07.md:113-113]

## Promoted From Short-Term Memory (2026-05-14)

<!-- openclaw-memory-promotion:memory:memory/2026-05-08.md:158:161 -->
- - Candidate: Reflections: Theme: `reflections` kept surfacing across 347 memories.; confidence: 1.00; evidence: memory/2026-04-24.md:318-321, memory/2026-04-24.md:322-325, memory/2026-04-24.md:326-329; note: reflection - confidence: 0.00 - evidence: memory/2026-05-08.md:158-161 - recalls: 0 [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-08.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-08.md:166:169 -->
- - Candidate: Reflections: Theme: `1.00` kept surfacing across 267 memories.; confidence: 0.86; evidence: memory/2026-04-24.md:318-321, memory/2026-04-24.md:322-325, memory/2026-04-24.md:326-329; note: reflection - confidence: 0.00 - evidence: memory/2026-05-08.md:166-169 - recalls: 0 [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-08.md:8-11]
<!-- openclaw-memory-promotion:memory:memory/2026-05-08.md:172:172 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-08.md:138-138]

## Promoted From Short-Term Memory (2026-05-15)

<!-- openclaw-memory-promotion:memory:memory/2026-05-09.md:263:266 -->
- - Candidate: Reflections: Theme: `reflections` kept surfacing across 326 memories.; confidence: 1.00; evidence: memory/2026-04-25.md:288-291, memory/2026-04-25.md:292-295, memory/2026-04-25.md:296-299; note: reflection - confidence: 0.00 - evidence: memory/2026-05-09.md:263-266 - recalls: 0 [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-09.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-09.md:271:274 -->
- - Candidate: Reflections: Theme: `1.00` kept surfacing across 258 memories.; confidence: 0.81; evidence: memory/2026-04-25.md:288-291, memory/2026-04-25.md:292-295, memory/2026-04-25.md:296-299; note: reflection - confidence: 0.00 - evidence: memory/2026-05-09.md:271-274 - recalls: 0 [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-09.md:8-11]
<!-- openclaw-memory-promotion:memory:memory/2026-05-09.md:277:277 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-09.md:133-133]

## Promoted From Short-Term Memory (2026-05-16)

<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:163:166 -->
- - Candidate: Reflections: Theme: `reflections` kept surfacing across 347 memories.; confidence: 1.00; evidence: memory/2026-04-26.md:238-241, memory/2026-04-26.md:242-245, memory/2026-04-26.md:246-249; note: reflection - confidence: 0.00 - evidence: memory/2026-05-10.md:163-166 - recalls: 0 [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-10.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:171:174 -->
- - Candidate: Reflections: Theme: `1.00` kept surfacing across 286 memories.; confidence: 0.86; evidence: memory/2026-04-26.md:238-241, memory/2026-04-26.md:242-245, memory/2026-04-26.md:246-249; note: reflection - confidence: 0.00 - evidence: memory/2026-05-10.md:171-174 - recalls: 0 [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-10.md:8-11]
<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:177:177 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-10.md:153-153]
<!-- openclaw-memory-promotion:memory:memory/2026-05-11.md:183:186 -->
- - Candidate: Reflections: Theme: `reflections` kept surfacing across 306 memories.; confidence: 0.98; evidence: memory/2026-04-27.md:303-306, memory/2026-04-27.md:307-310, memory/2026-04-27.md:311-314; note: reflection - confidence: 0.00 - evidence: memory/2026-05-11.md:188-191 - recalls: 0 [score=0.854 recalls=0 avg=0.620 source=memory/2026-05-11.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-11.md:191:194 -->
- - Candidate: Reflections: Theme: `1.00` kept surfacing across 269 memories.; confidence: 0.86; evidence: memory/2026-04-27.md:303-306, memory/2026-04-27.md:307-310, memory/2026-04-27.md:311-314; note: reflection - confidence: 0.00 - evidence: memory/2026-05-11.md:196-199 - recalls: 0 [score=0.854 recalls=0 avg=0.620 source=memory/2026-05-11.md:8-11]
<!-- openclaw-memory-promotion:memory:memory/2026-05-11.md:197:197 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.854 recalls=0 avg=0.620 source=memory/2026-05-11.md:138-138]
