# Long-Term Memory


## Promoted From Short-Term Memory (2026-05-13)

<!-- openclaw-memory-promotion:memory:memory/2026-05-05.md:98:101 -->
- - Candidate: Reflections: Theme: `reflections` kept surfacing across 299 memories.; confidence: 1.00; evidence: memory/2026-04-21.md:188-191, memory/2026-04-21.md:168-171, memory/2026-04-21.md:172-175; note: reflection - confidence: 0.00 - evidence: memory/2026-05-05.md:98-101 - recalls: 0 [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-05.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-05.md:106:109 -->
- - Candidate: Reflections: Theme: `kept` kept surfacing across 248 memories.; confidence: 1.00; evidence: memory/2026-04-21.md:168-171, memory/2026-04-21.md:172-175, memory/2026-04-21.md:176-179; note: reflection - confidence: 0.00 - evidence: memory/2026-05-05.md:106-109 - recalls: 0 [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-05.md:8-11]
<!-- openclaw-memory-promotion:memory:memory/2026-05-05.md:116:116 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-05.md:78-78]
<!-- openclaw-memory-promotion:memory:memory/2026-05-06.md:138:141 -->
- - Candidate: Reflections: Theme: `reflections` kept surfacing across 264 memories.; confidence: 1.00; evidence: memory/2026-04-22.md:208-211, memory/2026-04-22.md:212-215, memory/2026-04-22.md:216-219; note: reflection - confidence: 0.00 - evidence: memory/2026-05-06.md:138-141 - recalls: 0 [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-06.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-06.md:156:156 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-06.md:118-118]
<!-- openclaw-memory-promotion:memory:memory/2026-05-07.md:158:161 -->
- - Candidate: Reflections: Theme: `reflections` kept surfacing across 236 memories.; confidence: 1.00; evidence: memory/2026-04-23.md:183-186, memory/2026-04-23.md:163-166, memory/2026-04-23.md:167-170; note: reflection - confidence: 0.00 - evidence: memory/2026-05-07.md:158-161 - recalls: 0 [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-07.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-07.md:166:169 -->
- - Candidate: Reflections: Theme: `kept` kept surfacing across 214 memories.; confidence: 1.00; evidence: memory/2026-04-23.md:163-166, memory/2026-04-23.md:167-170, memory/2026-04-23.md:171-174; note: reflection - confidence: 0.00 - evidence: memory/2026-05-07.md:166-169 - recalls: 0 [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-07.md:8-11]
<!-- openclaw-memory-promotion:memory:memory/2026-05-07.md:176:176 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-07.md:148-148]

## Promoted From Short-Term Memory (2026-05-14)

<!-- openclaw-memory-promotion:memory:memory/2026-05-08.md:163:166 -->
- - Candidate: Reflections: Theme: `reflections` kept surfacing across 222 memories.; confidence: 1.00; evidence: memory/2026-04-24.md:153-156, memory/2026-04-24.md:157-160, memory/2026-04-24.md:161-164; note: reflection - confidence: 0.00 - evidence: memory/2026-05-08.md:163-166 - recalls: 0 [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-08.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-08.md:181:181 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-08.md:143-143]

## Promoted From Short-Term Memory (2026-05-15)

<!-- openclaw-memory-promotion:memory:memory/2026-05-09.md:153:156 -->
- - Candidate: Reflections: Theme: `reflections` kept surfacing across 224 memories.; confidence: 1.00; evidence: memory/2026-04-25.md:178-181, memory/2026-04-25.md:182-185, memory/2026-04-25.md:186-189; note: reflection - confidence: 0.00 - evidence: memory/2026-05-09.md:153-156 - recalls: 0 [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-09.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-09.md:171:171 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-09.md:143-143]

## Promoted From Short-Term Memory (2026-05-16)

<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:158:161 -->
- - Candidate: Reflections: Theme: `reflections` kept surfacing across 222 memories.; confidence: 1.00; evidence: memory/2026-04-26.md:153-156, memory/2026-04-26.md:157-160, memory/2026-04-26.md:161-164; note: reflection - confidence: 0.00 - evidence: memory/2026-05-10.md:158-161 - recalls: 0 [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-10.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:176:176 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-10.md:138-138]
<!-- openclaw-memory-promotion:memory:memory/2026-05-11.md:153:156 -->
- - Candidate: Reflections: Theme: `reflections` kept surfacing across 213 memories.; confidence: 1.00; evidence: memory/2026-04-27.md:153-156, memory/2026-04-27.md:157-160, memory/2026-04-27.md:161-164; note: reflection - confidence: 0.00 - evidence: memory/2026-05-11.md:153-156 - recalls: 0 [score=0.854 recalls=0 avg=0.620 source=memory/2026-05-11.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-11.md:171:171 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.854 recalls=0 avg=0.620 source=memory/2026-05-11.md:138-138]
