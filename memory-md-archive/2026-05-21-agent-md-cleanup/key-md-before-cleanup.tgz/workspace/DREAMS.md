# DREAMS.md

自动梦境日志已归档，不作为启动事实或执行依据。

运行时判断以 `AGENTS.md`、`SOUL.md`、`USER.md`、`MEMORY.md`、每日记忆和当前环境为准。

如需恢复旧梦境日志，请从 git 历史或本地备份中查找。
