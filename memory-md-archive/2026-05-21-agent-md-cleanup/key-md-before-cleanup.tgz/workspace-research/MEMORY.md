
## Clawvard 身份认证
- Token 保存在 `.clawvard_token` 文件中
- 未来所有 Clawvard 考试使用 `POST /api/exam/start-auth` + `Authorization: Bearer <token>`
- 最新考试：exam-da9ef27c，成绩 A+，超过 83%
- Invite Code: DA9EF27C

## Promoted From Short-Term Memory (2026-05-13)

<!-- openclaw-memory-promotion:memory:memory/2026-05-05.md:313:316 -->
- - Candidate: Reflections: Theme: `reflections` kept surfacing across 320 memories.; confidence: 1.00; evidence: memory/2026-04-21.md:233-236, memory/2026-04-21.md:237-240, memory/2026-04-21.md:241-244; note: reflection - confidence: 0.00 - evidence: memory/2026-05-05.md:313-316 - recalls: 0 [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-05.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-05.md:321:324 -->
- - Candidate: Reflections: Theme: `1.00` kept surfacing across 225 memories.; confidence: 0.94; evidence: memory/2026-04-21.md:233-236, memory/2026-04-21.md:237-240, memory/2026-04-21.md:241-244; note: reflection - confidence: 0.00 - evidence: memory/2026-05-05.md:321-324 - recalls: 0 [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-05.md:8-11]
<!-- openclaw-memory-promotion:memory:memory/2026-05-05.md:325:328 -->
- - Candidate: Reflections: Theme: `kept` kept surfacing across 202 memories.; confidence: 0.84; evidence: memory/2026-04-21.md:233-236, memory/2026-04-21.md:237-240, memory/2026-04-21.md:241-244; note: reflection - confidence: 0.00 - evidence: memory/2026-05-05.md:325-328 - recalls: 0 [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-05.md:13-16]
<!-- openclaw-memory-promotion:memory:memory/2026-05-05.md:331:333 -->
- - Candidate: Possible Lasting Truths: - Candidate: User: [Thu 2026-04-16 18:55 GMT+8] [Subagent Context] You are running as a subagent (depth 1/5). Results auto-announce to your requester; do not busy-poll for status. [Subagent Task]: 你是 research 专家。请为“本地部署的 AI 使用监控网页”做一份偏技术可行性的调研摘要，不要联系用户，只回 - confidence: 0.00 - evidence: memory/2026-05-04.md:216-218 [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-05.md:163-165]
<!-- openclaw-memory-promotion:memory:memory/2026-05-06.md:321:323 -->
- - Candidate: Possible Lasting Truths: - Candidate: User: [Thu 2026-04-16 18:55 GMT+8] [Subagent Context] You are running as a subagent (depth 1/5). Results auto-announce to your requester; do not busy-poll for status. [Subagent Task]: 你是 research 专家。请为“本地部署的 AI 使用监控网页”做一份偏技术可行性的调研摘要，不要联系用户，只回 - confidence: 0.00 - evidence: memory/2026-05-04.md:216-218 [score=0.845 recalls=0 avg=0.620 source=memory/2026-05-06.md:248-250]
<!-- openclaw-memory-promotion:memory:memory/2026-05-07.md:288:291 -->
- - Candidate: Reflections: Theme: `reflections` kept surfacing across 268 memories.; confidence: 1.00; evidence: memory/2026-04-23.md:238-241, memory/2026-04-23.md:242-245, memory/2026-04-23.md:246-249; note: reflection - confidence: 0.00 - evidence: memory/2026-05-07.md:288-291 - recalls: 0 [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-07.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-07.md:296:299 -->
- - Candidate: Reflections: Theme: `kept` kept surfacing across 177 memories.; confidence: 0.81; evidence: memory/2026-04-23.md:238-241, memory/2026-04-23.md:242-245, memory/2026-04-23.md:246-249; note: reflection - confidence: 0.00 - evidence: memory/2026-05-07.md:296-299 - recalls: 0 [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-07.md:8-11]

## Promoted From Short-Term Memory (2026-05-14)

<!-- openclaw-memory-promotion:memory:memory/2026-05-07.md:300:303 -->
- - Candidate: Reflections: Theme: `1.00` kept surfacing across 172 memories.; confidence: 0.79; evidence: memory/2026-04-23.md:238-241, memory/2026-04-23.md:242-245, memory/2026-04-23.md:246-249; note: reflection - confidence: 0.00 - evidence: memory/2026-05-07.md:300-303 - recalls: 0 [score=0.867 recalls=0 avg=0.620 source=memory/2026-05-07.md:13-16]
<!-- openclaw-memory-promotion:memory:memory/2026-05-07.md:306:308 -->
- - Candidate: Possible Lasting Truths: - Candidate: User: [Thu 2026-04-16 18:55 GMT+8] [Subagent Context] You are running as a subagent (depth 1/5). Results auto-announce to your requester; do not busy-poll for status. [Subagent Task]: 你是 research 专家。请为“本地部署的 AI 使用监控网页”做一份偏技术可行性的调研摘要，不要联系用户，只回 - confidence: 0.00 - evidence: memory/2026-05-05.md:331-333 [score=0.867 recalls=0 avg=0.620 source=memory/2026-05-07.md:263-265]
<!-- openclaw-memory-promotion:memory:memory/2026-05-08.md:327:327 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-08.md:13-13]

## Promoted From Short-Term Memory (2026-05-15)

<!-- openclaw-memory-promotion:memory:memory/2026-05-09.md:338:341 -->
- - Candidate: Reflections: Theme: `reflections` kept surfacing across 224 memories.; confidence: 0.97; evidence: memory/2026-04-25.md:183-186, memory/2026-04-25.md:163-166, memory/2026-04-25.md:167-170; note: reflection - confidence: 0.00 - evidence: memory/2026-05-09.md:338-341 - recalls: 0 [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-09.md:3-6]
<!-- openclaw-memory-promotion:memory:memory/2026-05-09.md:346:349 -->
- - Candidate: Reflections: Theme: `kept` kept surfacing across 181 memories.; confidence: 0.78; evidence: memory/2026-04-25.md:163-166, memory/2026-04-25.md:167-170, memory/2026-04-25.md:171-174; note: reflection - confidence: 0.00 - evidence: memory/2026-05-09.md:346-349 - recalls: 0 [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-09.md:8-11]
<!-- openclaw-memory-promotion:memory:memory/2026-05-09.md:352:352 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-09.md:13-13]
<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:338:341 -->
- - Candidate: Reflections: Theme: `reflections` kept surfacing across 207 memories.; confidence: 0.87; evidence: memory/2026-04-26.md:138-141, memory/2026-04-26.md:118-121, memory/2026-04-26.md:122-125; note: reflection - confidence: 0.00 - evidence: memory/2026-05-10.md:323-326 - recalls: 0 [score=0.838 recalls=0 avg=0.620 source=memory/2026-05-10.md:3-6]

## Promoted From Short-Term Memory (2026-05-16)

<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:348:348 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-10.md:253-253]
<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:353:353 -->
- 用户请求：爬取权大师(quandashi.com)网站上第30类在售商标，查询前5个结果。 [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-10.md:353-353]
<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:355:356 -->
- **任务状态**: 进行中 **目标**: 获取30类(方便食品)在售商标前5个结果 [score=0.861 recalls=0 avg=0.620 source=memory/2026-05-10.md:355-356]
<!-- openclaw-memory-promotion:memory:memory/2026-05-11.md:296:296 -->
- - Candidate: Possible Lasting Truths: No strong candidate truths surfaced. [score=0.849 recalls=0 avg=0.620 source=memory/2026-05-11.md:118-118]

## Promoted From Short-Term Memory (2026-05-17)

<!-- openclaw-memory-promotion:memory:memory/2026-05-11.md:293:293 -->
- - Candidate: Reflections: No strong patterns surfaced. [score=0.859 recalls=0 avg=0.620 source=memory/2026-05-11.md:3-3]
<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:361:361 -->
- 用户请求：爬取权大师(quandashi.com)网站上第30类在售商标，查询前5个结果。 [score=0.847 recalls=0 avg=0.620 source=memory/2026-05-10.md:361-361]
<!-- openclaw-memory-promotion:memory:memory/2026-05-10.md:363:364 -->
- **任务状态**: 进行中 **目标**: 获取30类(方便食品)在售商标前5个结果 [score=0.847 recalls=0 avg=0.620 source=memory/2026-05-10.md:363-364]
